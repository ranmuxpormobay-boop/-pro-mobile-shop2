The `images` folder contains brand-specific smartphone artwork used by the
“ร้านมือโปรโมบาย” web application.  Each image was generated using an AI
image generation model to approximate the look and feel of phones from the
corresponding brand.  The images are abstract, free of trademarks or logos,
and safe for inclusion in the app.  They are named according to the brand
they represent (e.g. `samsung.png`, `vivo.png` etc.).

If you wish to update these images in the future, simply replace the files
with your own photos while preserving the same filenames so the scripts
continue to load them correctly.