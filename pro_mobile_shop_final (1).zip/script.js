/*
 * Script for ร้านมือโปรโมบาย web app.
 * Handles product rendering, search functionality and customer details.
 */

// Global array to hold products loaded from JSON
let products = [];
// Separate search terms for brand and model filtering
let brandSearchTerm = '';
let modelSearchTerm = '';

// Array of saved customers, loaded from localStorage
let customers = [];

// Map of brand names to default image paths.  Each entry maps the
// uppercase brand (without extra spaces) to a relative path in the
// `images` directory.  These images are abstract representations of
// phones with colours inspired by the respective brands.
const BRAND_IMAGES = {
  'SAMSUNG': 'images/samsung.jpg',
  // The SAMSUNG TAB tablets use the same colour palette as Samsung
  'SAMSUNG TAB': 'images/samsung.jpg',
  'VIVO': 'images/vivo.jpg',
  'OPPO': 'images/oppo.jpg',
  'REALME': 'images/realme.jpg',
  'NOKIA-HMD': 'images/nokia-hmd.jpg',
  'HONOR': 'images/honor.jpg',
};

// Embedded product data loaded from mpm-huaiyae-prices.json for offline use.
// The array below contains all mobile phones with their selling price and specs (RAM/ROM).
const RAW_ITEMS = [
{id: 'SAMSUNG-A06_(4/64)', brand: 'SAMSUNG', model: 'A06 (4/64)', retail: 3399, wholesale: 2750, consign: 3059, note: '', image: ''},
{id: 'SAMSUNG-A06_(4/128)', brand: 'SAMSUNG', model: 'A06 (4/128)', retail: 3999, wholesale: 3550, consign: 3599, note: '', image: ''},
{id: 'SAMSUNG-A06-5G_(6/128)', brand: 'SAMSUNG', model: 'A06-5G (6/128)', retail: 5499, wholesale: 4470, consign: 4949, note: '', image: ''},
{id: 'SAMSUNG-A16-5G_(4/128)', brand: 'SAMSUNG', model: 'A16-5G (4/128)', retail: 5999, wholesale: 5400, consign: 5519, note: '', image: ''},
{id: 'SAMSUNG-A16-5G_(8/256)', brand: 'SAMSUNG', model: 'A16-5G (8/256)', retail: 8499, wholesale: 7250, consign: 7649, note: '', image: ''},
{id: 'SAMSUNG-A25-5G_(8/256)', brand: 'SAMSUNG', model: 'A25-5G (8/256)', retail: 10999, wholesale: 8900, consign: 9899, note: '', image: ''},
{id: 'SAMSUNG-A26-5G_(8/256)', brand: 'SAMSUNG', model: 'A26-5G (8/256)', retail: 10999, wholesale: 0, consign: 0, note: 'Cr 15 วัน = 0 ในแผ่น', image: ''},
{id: 'SAMSUNG-A36-128_(8/128)', brand: 'SAMSUNG', model: 'A36-128 (8/128)', retail: 11990, wholesale: 10650, consign: 10791, note: '', image: ''},
{id: 'SAMSUNG-A55-256_(8/256)', brand: 'SAMSUNG', model: 'A55-256 (8/256)', retail: 15999, wholesale: 13300, consign: 14399, note: '', image: ''},
{id: 'SAMSUNG-A56-5G_(8/128)', brand: 'SAMSUNG', model: 'A56-5G (8/128)', retail: 13999, wholesale: 12000, consign: 12599, note: '', image: ''},
{id: 'SAMSUNG-A56-5G_(12/256)', brand: 'SAMSUNG', model: 'A56-5G (12/256)', retail: 15999, wholesale: 13300, consign: 0, note: '', image: ''},
{id: 'SAMSUNG-S24_FE_(8/128)', brand: 'SAMSUNG', model: 'S24 FE (8/128)', retail: 22900, wholesale: 18200, consign: 20610, note: '', image: ''},
{id: 'SAMSUNG-S24_FE_(8/256)', brand: 'SAMSUNG', model: 'S24 FE (8/256)', retail: 25900, wholesale: 21000, consign: 23310, note: '', image: ''},
{id: 'SAMSUNG-S23_Ultra_(8/256)', brand: 'SAMSUNG', model: 'S23 Ultra (8/256)', retail: 41900, wholesale: 30900, consign: 37710, note: '', image: ''},
{id: 'SAMSUNG-S24_Plus_(12/512)', brand: 'SAMSUNG', model: 'S24 Plus (12/512)', retail: 38900, wholesale: 34500, consign: 35010, note: '', image: ''},
{id: 'SAMSUNG-S24_Ultra_(12/256)', brand: 'SAMSUNG', model: 'S24 Ultra (12/256)', retail: 42900, wholesale: 32500, consign: 38610, note: '', image: ''},
{id: 'SAMSUNG-S24_Ultra_(12/512)', brand: 'SAMSUNG', model: 'S24 Ultra (12/512)', retail: 48900, wholesale: 39500, consign: 44010, note: '', image: ''},
{id: 'SAMSUNG-S25_(12/512)_ประกันจอ', brand: 'SAMSUNG', model: 'S25 (12/512) ประกันจอ', retail: 34900, wholesale: 38500, consign: 31410, note: '', image: ''},
{id: 'SAMSUNG-S25+_(12/512)_ประกันจอ', brand: 'SAMSUNG', model: 'S25+ (12/512) ประกันจอ', retail: 41900, wholesale: 34500, consign: 37710, note: '', image: ''},
{id: 'SAMSUNG-S25_Ultra_(12/512)_ประกันจอ', brand: 'SAMSUNG', model: 'S25 Ultra (12/512) ประกันจอ', retail: 48900, wholesale: 43500, consign: 44010, note: '', image: ''},
{id: 'SAMSUNG-Fold_6-5G_(12/256)', brand: 'SAMSUNG', model: 'Fold 6-5G (12/256)', retail: 63900, wholesale: 50900, consign: 57510, note: '', image: ''},
{id: 'SAMSUNG_TAB-Tab_A9_LTE_(4/64)', brand: 'SAMSUNG TAB', model: 'Tab A9 LTE (4/64)', retail: 5990, wholesale: 4750, consign: 0, note: '', image: ''},
{id: 'SAMSUNG_TAB-Tab_A9_LTE_(8/128)', brand: 'SAMSUNG TAB', model: 'Tab A9 LTE (8/128)', retail: 6999, wholesale: 5600, consign: 0, note: '', image: ''},
{id: 'SAMSUNG_TAB-Tab_A9_+_WIFI_(8/128)', brand: 'SAMSUNG TAB', model: 'Tab A9 + WIFI (8/128)', retail: 7990, wholesale: 6900, consign: 0, note: '', image: ''},
{id: 'SAMSUNG_TAB-Tab_A9_+_Sim_(8/128)', brand: 'SAMSUNG TAB', model: 'Tab A9 + Sim (8/128)', retail: 9990, wholesale: 8700, consign: 0, note: '', image: ''},
{id: 'SAMSUNG_TAB-Tab_S6_lite_2024_(4/128)', brand: 'SAMSUNG TAB', model: 'Tab S6 lite 2024 (4/128)', retail: 11990, wholesale: 9800, consign: 0, note: '', image: ''},
{id: 'SAMSUNG_TAB-Tab-S9_FE-WIFI_(6/128)', brand: 'SAMSUNG TAB', model: 'Tab-S9 FE-WIFI (6/128)', retail: 16990, wholesale: 13200, consign: 0, note: '', image: ''},
{id: 'SAMSUNG_TAB-Tab-S9_FE-Sim_(6/128)', brand: 'SAMSUNG TAB', model: 'Tab-S9 FE-Sim (6/128)', retail: 19990, wholesale: 14900, consign: 0, note: '', image: ''},
{id: 'SAMSUNG_TAB-Tab_S9_FE_Plus_WIFI_(8/128)', brand: 'SAMSUNG TAB', model: 'Tab S9 FE Plus WIFI (8/128)', retail: 23900, wholesale: 17600, consign: 0, note: '', image: ''},
{id: 'SAMSUNG_TAB-Tab_S9_FE_Plus_SIM_(8/128)', brand: 'SAMSUNG TAB', model: 'Tab S9 FE Plus SIM (8/128)', retail: 27900, wholesale: 19900, consign: 0, note: '', image: ''},
{id: 'SAMSUNG_TAB-Tab-S10_FE-WIFI_(8/128)', brand: 'SAMSUNG TAB', model: 'Tab-S10 FE-WIFI (8/128)', retail: 17900, wholesale: 15850, consign: 0, note: '', image: ''},
{id: 'SAMSUNG_TAB-Tab-S10_FE-SIM_(8/128)', brand: 'SAMSUNG TAB', model: 'Tab-S10 FE-SIM (8/128)', retail: 20900, wholesale: 18500, consign: 0, note: '', image: ''},
{id: 'SAMSUNG_TAB-Tab-S10_FE_Plus-WIFI_(12/256)', brand: 'SAMSUNG TAB', model: 'Tab-S10 FE Plus-WIFI (12/256)', retail: 26900, wholesale: 23800, consign: 0, note: '', image: ''},
{id: 'SAMSUNG_TAB-Tab-S10_FE-_Plus-SIM_(12/256)', brand: 'SAMSUNG TAB', model: 'Tab-S10 FE- Plus-SIM (12/256)', retail: 29900, wholesale: 26500, consign: 0, note: '', image: ''},
{id: 'SAMSUNG_TAB-Tab-S10_+_WIFI_(12/256)', brand: 'SAMSUNG TAB', model: 'Tab-S10 + WIFI (12/256)', retail: 36900, wholesale: 32500, consign: 0, note: '', image: ''},
{id: 'SAMSUNG_TAB-Tab-S10_+_SIM_(12/256)', brand: 'SAMSUNG TAB', model: 'Tab-S10 + SIM (12/256)', retail: 41900, wholesale: 37000, consign: 0, note: '', image: ''},
{id: 'VIVO-Y03T_(4/64)', brand: 'VIVO', model: 'Y03T (4/64)', retail: 2999, wholesale: 2620, consign: 2759, note: '', image: ''},
{id: 'VIVO-Y03T_(4/128)', brand: 'VIVO', model: 'Y03T (4/128)', retail: 3499, wholesale: 3035, consign: 3219, note: '', image: ''},
{id: 'VIVO-Y04_(4/64)', brand: 'VIVO', model: 'Y04 (4/64)', retail: 3299, wholesale: 2890, consign: 3035, note: '', image: ''},
{id: 'VIVO-Y19s_(4/64)', brand: 'VIVO', model: 'Y19s (4/64)', retail: 4399, wholesale: 3440, consign: 3599, note: '', image: ''},
{id: 'VIVO-Y19s_(4/128)', brand: 'VIVO', model: 'Y19s (4/128)', retail: 4399, wholesale: 3800, consign: 3959, note: '', image: ''},
{id: 'VIVO-Y19s_(6/128)', brand: 'VIVO', model: 'Y19s (6/128)', retail: 4999, wholesale: 4250, consign: 4499, note: '', image: ''},
{id: 'VIVO-Y28-8/128', brand: 'VIVO', model: 'Y28-8/128', retail: 5499, wholesale: 4780, consign: 4949, note: '', image: ''},
{id: 'VIVO-Y39-5G_(8/256)', brand: 'VIVO', model: 'Y39-5G (8/256)', retail: 7999, wholesale: 6750, consign: 7199, note: '', image: ''},
{id: 'VIVO-Y200-5G_(12/512)', brand: 'VIVO', model: 'Y200-5G (12/512)', retail: 11999, wholesale: 9900, consign: 10799, note: '', image: ''},
{id: 'VIVO-V30_Pro-5G_(12/512)_โปรโมชัน', brand: 'VIVO', model: 'V30 Pro-5G (12/512) โปรโมชัน', retail: 19999, wholesale: 14900, consign: 17499, note: '', image: ''},
{id: 'VIVO-V40_(12/256)_ปรับราคา', brand: 'VIVO', model: 'V40 (12/256) ปรับราคา', retail: 13999, wholesale: 11750, consign: 12599, note: '', image: ''},
{id: 'VIVO-V50_(12/256)', brand: 'VIVO', model: 'V50 (12/256)', retail: 15999, wholesale: 13200, consign: 14399, note: '', image: ''},
{id: 'VIVO-X200_(12/256)', brand: 'VIVO', model: 'X200 (12/256)', retail: 29999, wholesale: 25200, consign: 26999, note: '', image: ''},
{id: 'VIVO-X200_Pro_(16/512)', brand: 'VIVO', model: 'X200 Pro (16/512)', retail: 39999, wholesale: 34000, consign: 35999, note: '', image: ''},
{id: 'VIVO-IQOO_Z9_(12/256)', brand: 'VIVO', model: 'IQOO Z9 (12/256)', retail: 11499, wholesale: 10200, consign: 10349, note: '', image: ''},
{id: 'VIVO-V50_(12/256)_(รายการซ้ำ-อีกบรรทัด)', brand: 'VIVO', model: 'V50 (12/256) (รายการซ้ำ-อีกบรรทัด)', retail: 15999, wholesale: 13200, consign: 14399, note: '', image: ''},
{id: 'OPPO-A3x_(4/64)', brand: 'OPPO', model: 'A3x (4/64)', retail: 2999, wholesale: 2690, consign: 2759, note: '', image: ''},
{id: 'OPPO-A3x_(4/128)', brand: 'OPPO', model: 'A3x (4/128)', retail: 3999, wholesale: 3580, consign: 3679, note: '', image: ''},
{id: 'OPPO-A3x_(6/128)', brand: 'OPPO', model: 'A3x (6/128)', retail: 4999, wholesale: 4430, consign: 4599, note: '', image: ''},
{id: 'OPPO-A3_(8/128)', brand: 'OPPO', model: 'A3 (8/128)', retail: 5499, wholesale: 4800, consign: 4949, note: '', image: ''},
{id: 'OPPO-A3_(8/256)', brand: 'OPPO', model: 'A3 (8/256)', retail: 6499, wholesale: 5700, consign: 5849, note: '', image: ''},
{id: 'OPPO-A3_Pro-5G_(6/128)', brand: 'OPPO', model: 'A3 Pro-5G (6/128)', retail: 7499, wholesale: 6500, consign: 6749, note: '', image: ''},
{id: 'OPPO-A3_Pro-5G_(8/256)', brand: 'OPPO', model: 'A3 Pro-5G (8/256)', retail: 8999, wholesale: 7700, consign: 8099, note: '', image: ''},
{id: 'OPPO-A5_Pro-4G_(8/128)', brand: 'OPPO', model: 'A5 Pro-4G (8/128)', retail: 5999, wholesale: 5260, consign: 5399, note: '', image: ''},
{id: 'OPPO-A5_Pro-4G_(8/256)', brand: 'OPPO', model: 'A5 Pro-4G (8/256)', retail: 6999, wholesale: 5850, consign: 6299, note: '', image: ''},
{id: 'OPPO-A5_Pro-5G_(8/256)', brand: 'OPPO', model: 'A5 Pro-5G (8/256)', retail: 8999, wholesale: 6850, consign: 7199, note: '', image: ''},
{id: 'OPPO-A5_Pro-5G_(12/256)', brand: 'OPPO', model: 'A5 Pro-5G (12/256)', retail: 9999, wholesale: 8450, consign: 8759, note: '', image: ''},
{id: 'OPPO-Reno_13F_(12/256)', brand: 'OPPO', model: 'Reno 13F (12/256)', retail: 12999, wholesale: 10900, consign: 13499, note: '', image: ''},
{id: 'OPPO-Reno_13F_(12/512)', brand: 'OPPO', model: 'Reno 13F (12/512)', retail: 14999, wholesale: 12600, consign: 13499, note: '', image: ''},
{id: 'OPPO-Reno_13-5G_(12/256)', brand: 'OPPO', model: 'Reno 13-5G (12/256)', retail: 17999, wholesale: 15100, consign: 16199, note: '', image: ''},
{id: 'OPPO-Reno_13-5G_(12/512)', brand: 'OPPO', model: 'Reno 13-5G (12/512)', retail: 19999, wholesale: 16800, consign: 17999, note: '', image: ''},
{id: 'OPPO-Reno_13_Pro-5G_(12/512)', brand: 'OPPO', model: 'Reno 13 Pro-5G (12/512)', retail: 24999, wholesale: 21000, consign: 22499, note: '', image: ''},
{id: 'OPPO-Find_X8_(12/256)', brand: 'OPPO', model: 'Find X8 (12/256)', retail: 29990, wholesale: 24900, consign: 26991, note: '', image: ''},
{id: 'OPPO-OPPO_Pad_NEO_(8/128)', brand: 'OPPO', model: 'OPPO Pad NEO (8/128)', retail: 10990, wholesale: 9300, consign: 9891, note: '', image: ''},
{id: 'Realme-Note_60x_(4/64)', brand: 'Realme', model: 'Note 60x (4/64)', retail: 2999, wholesale: 2700, consign: 2759, note: '', image: ''},
{id: 'Realme-C75x_(6/128)', brand: 'Realme', model: 'C75x (6/128)', retail: 4999, wholesale: 4399, consign: 4499, note: '', image: ''},
{id: 'Realme-C75_(8/128)', brand: 'Realme', model: 'C75 (8/128)', retail: 5999, wholesale: 5279, consign: 5399, note: '', image: ''},
{id: 'Realme-C75-8/256', brand: 'Realme', model: 'C75-8/256', retail: 6999, wholesale: 6158, consign: 6299, note: '', image: ''},
{id: 'Realme-C53-8/256_ลดราคา', brand: 'Realme', model: 'C53-8/256 ลดราคา', retail: 5499, wholesale: 3900, consign: 4949, note: '', image: ''},
{id: 'Realme-Realme_14-5G_(12/256)', brand: 'Realme', model: 'Realme 14-5G (12/256)', retail: 11999, wholesale: 10439, consign: 10799, note: '', image: ''},
{id: 'Realme-Realme_13-5G_(12/256)', brand: 'Realme', model: 'Realme 13-5G (12/256)', retail: 8999, wholesale: 7673, consign: 8099, note: '', image: ''},
{id: 'Realme-Realme_13+5G_(12/256)', brand: 'Realme', model: 'Realme 13+5G (12/256)', retail: 11999, wholesale: 10230, consign: 10799, note: '', image: ''},
{id: 'Realme-Realme_Pad-mini_SIM_(3/32)', brand: 'Realme', model: 'Realme Pad-mini SIM (3/32)', retail: 6300, wholesale: 3990, consign: 5670, note: '', image: ''},
{id: 'Realme-Buds_T01', brand: 'Realme', model: 'Buds T01', retail: 999, wholesale: 590, consign: 899, note: '', image: ''},
{id: 'Realme-Buds_T110', brand: 'Realme', model: 'Buds T110', retail: 999, wholesale: 590, consign: 899, note: '', image: ''},
{id: 'NOKIA-HMD-NOKIA_108-4G', brand: 'NOKIA-HMD', model: 'NOKIA 108-4G', retail: 1320, wholesale: 1162, consign: 1188, note: '', image: ''},
{id: 'NOKIA-HMD-NOKIA_3210-2024-4G', brand: 'NOKIA-HMD', model: 'NOKIA 3210-2024-4G', retail: 1990, wholesale: 1750, consign: 1791, note: '', image: ''},
{id: 'NOKIA-HMD-HMD_ARC_(4/64)', brand: 'NOKIA-HMD', model: 'HMD ARC (4/64)', retail: 2290, wholesale: 1992, consign: 2061, note: '', image: ''},
{id: 'NOKIA-HMD-HMD_Aura_2_(4/128)', brand: 'NOKIA-HMD', model: 'HMD Aura 2 (4/128)', retail: 2490, wholesale: 2166, consign: 2241, note: '', image: ''},
{id: 'NOKIA-HMD-HMD_Plus_(4/128)', brand: 'NOKIA-HMD', model: 'HMD Plus (4/128)', retail: 3290, wholesale: 2650, consign: 2961, note: '', image: ''},
{id: 'HONOR-Honor_X5b_Plus_(4/128)', brand: 'HONOR', model: 'Honor X5b Plus (4/128)', retail: 3299, wholesale: 2880, consign: 2969, note: '', image: ''},
{id: 'HONOR-Honor_X6a_(4/128)', brand: 'HONOR', model: 'Honor X6a (4/128)', retail: 3999, wholesale: 3400, consign: 3599, note: '', image: ''},
{id: 'HONOR-Honor_X6b_(6/128)', brand: 'HONOR', model: 'Honor X6b (6/128)', retail: 3999, wholesale: 3400, consign: 3599, note: '', image: ''},
{id: 'HONOR-Honor_X7c_(8/256_+_Buds)', brand: 'HONOR', model: 'Honor X7c (8/256 + Buds)', retail: 5999, wholesale: 5100, consign: 5399, note: '', image: ''},
{id: 'HONOR-Honor_X9c_(12/256_+_Buds)', brand: 'HONOR', model: 'Honor X9c (12/256 + Buds)', retail: 10990, wholesale: 9450, consign: 9891, note: '', image: ''},
{id: 'HONOR-Honor_Magic_7_Pro_(12/512)', brand: 'HONOR', model: 'Honor Magic 7 Pro (12/512)', retail: 35900, wholesale: 29500, consign: 32310, note: '', image: ''},
{id: 'HONOR-Honor_Pad_9_WIFI_(8/256)', brand: 'HONOR', model: 'Honor Pad 9 WIFI (8/256)', retail: 10990, wholesale: 9250, consign: 9891, note: '', image: ''}
];

/**
 * Normalize item from JSON to our internal product format.
 * We derive a description/spec string from the model (e.g. parse memory) and brand.
 * @param {Object} item The raw item from JSON
 * @returns {Object}
 */
function normalizeItem(item) {
  const id = item.id || `${item.brand}-${item.model}`;
  // Build a friendly name combining brand and model
  const name = `${item.brand} ${item.model}`;
  // Attempt to extract spec from parentheses in model, e.g. (8/256)
  let spec = '';
  const match = /\(([^)]+)\)/.exec(item.model);
  if (match) {
    const parts = match[1].split('/');
    if (parts.length === 2) {
      // Assume first is RAM, second is storage
      spec = `${parts[0].trim()}GB RAM / ${parts[1].trim()}GB ROM`;
    } else {
      spec = match[1];
    }
  }
  // Include brand as part of description
  const description = spec
    ? `${item.brand.toUpperCase()} | ${spec}`
    : `${item.brand.toUpperCase()}`;
  // Choose an appropriate image: if the JSON provides one, use it;
  // otherwise fall back to a brand-specific default image.  Normalise
  // the brand key to uppercase for lookup.  If no mapping exists, the
  // image will remain an empty string and the card will display the
  // generic phone icon.
  const brandKey = (item.brand || '').trim().toUpperCase();
  const imagePath = item.image && item.image.trim() ? item.image : BRAND_IMAGES[brandKey] || '';
  return {
    id,
    name,
    description,
    price: Number(item.retail || 0),
    wholesale: Number(item.wholesale || 0),
    consign: Number(item.consign || 0),
    note: item.note || '',
    image: imagePath,
    // Include brand and model fields for filtering
    brand: item.brand || '',
    model: item.model || '',
  };
}

/**
 * Fetch products from the local JSON file and normalize them.
 * Falls back to an empty array if the request fails.
 */
async function fetchProducts() {
  // Attempt to fetch the JSON file dynamically.  If running from file:// protocol this
  // will likely fail due to CORS restrictions, so we fall back to the embedded RAW_ITEMS.
  try {
    const response = await fetch('mpm-huaiyae-prices.json');
    if (!response.ok) throw new Error('Network response was not ok');
    const raw = await response.json();
    if (Array.isArray(raw) && raw.length > 0) {
      products = raw.map(normalizeItem);
      return;
    }
  } catch (err) {
    console.warn('Falling back to embedded product data:', err);
  }
  // Use embedded data if fetch fails or returns empty.
  products = RAW_ITEMS.map(normalizeItem);
}

// Function to render the product list
function renderProducts() {
  const productList = document.getElementById('product-list');
  productList.innerHTML = '';
  // Filter products based on brand and model search terms
  const brandTerm = (brandSearchTerm || '').trim().toLowerCase();
  const modelTerm = (modelSearchTerm || '').trim().toLowerCase();
  const listToShow = products.filter((p) => {
    let match = true;
    if (brandTerm) {
      match = match && p.brand.toLowerCase().includes(brandTerm);
    }
    if (modelTerm) {
      const m = p.model ? p.model.toLowerCase() : '';
      match = match && (m.includes(modelTerm) || p.name.toLowerCase().includes(modelTerm));
    }
    return match;
  });
  if (!listToShow || listToShow.length === 0) {
    productList.innerHTML = '<p>ไม่พบสินค้า</p>';
    return;
  }
  listToShow.forEach((product) => {
    const card = document.createElement('div');
    card.className = 'product-card';
    // Use image if available, otherwise show emoji
    let imgHtml = '';
    if (product.image) {
      imgHtml = `<img src="${product.image}" alt="${product.name}" class="product-photo" />`;
    } else {
      imgHtml = `<div class="product-icon">📱</div>`;
    }
    card.innerHTML = `
      ${imgHtml}
      <div class="product-name">${product.name}</div>
      <div class="product-description">${product.description}</div>
      <div class="product-price">฿${product.price.toLocaleString()}</div>
    `;
    productList.appendChild(card);
  });
}

// Payment select population has been removed because the payment form was deleted.

// Handle payment form submission
/*
 * The payment section has been removed from this application, so the related
 * handler function and select population are no longer necessary.  Payment
 * functionality has been entirely removed as per user request.
 */

// Load customers from localStorage.  If the stored value cannot be parsed,
// an empty array will be used instead.
function loadCustomers() {
  try {
    const stored = localStorage.getItem('mpm_customers');
    customers = stored ? JSON.parse(stored) : [];
    if (!Array.isArray(customers)) customers = [];
  } catch (err) {
    customers = [];
  }
}

// Save current customers array to localStorage
function saveCustomers() {
  try {
    localStorage.setItem('mpm_customers', JSON.stringify(customers));
  } catch (err) {
    console.error('Failed to save customers to localStorage', err);
  }
}

// Render the customer list optionally filtered by a search term.  The term
// matches against the customer's name or phone number.
function renderCustomerList(filter = '') {
  const listDiv = document.getElementById('customer-list');
  if (!listDiv) return;
  const term = (filter || '').trim().toLowerCase();
  const filtered = term
    ? customers.filter((c) =>
        c.name.toLowerCase().includes(term) || c.phone.includes(term)
      )
    : customers;
  if (!filtered || filtered.length === 0) {
    listDiv.innerHTML = '<p>ไม่พบลูกค้า</p>';
    return;
  }
  const items = filtered
    .map(
      (c) =>
        `<li><strong>${c.name}</strong> - ${c.phone} - ${c.email} - ${c.address}</li>`
    )
    .join('');
  listDiv.innerHTML = `<ul>${items}</ul>`;
}

// Handle customer form submission
function handleCustomerSubmit(event) {
  event.preventDefault();
  const name = document.getElementById('customer-name').value.trim();
  const phone = document.getElementById('customer-phone').value.trim();
  const email = document.getElementById('customer-email').value.trim();
  const address = document.getElementById('customer-address').value.trim();
  const resultDiv = document.getElementById('customer-result');
  if (!name || !phone) {
    resultDiv.innerHTML = '<strong>กรุณากรอกชื่อและเบอร์โทร</strong>';
    return;
  }
  // Create a new customer record with timestamp for uniqueness
  const record = {
    id: Date.now(),
    name,
    phone,
    email,
    address,
    created: new Date().toISOString(),
  };
  customers.push(record);
  saveCustomers();
  // Update the customer list view
  renderCustomerList(document.getElementById('customer-search')?.value || '');
  resultDiv.innerHTML = `
    <strong>รายละเอียดลูกค้าบันทึกแล้ว</strong><br/>
    ชื่อ: ${name}<br/>
    เบอร์โทร: ${phone}<br/>
    อีเมล: ${email}<br/>
    ที่อยู่: ${address}<br/>
  `;
  // Clear form fields for the next entry
  document.getElementById('customer-name').value = '';
  document.getElementById('customer-phone').value = '';
  document.getElementById('customer-email').value = '';
  document.getElementById('customer-address').value = '';
}

// Update footer year
function updateYear() {
  const yearSpan = document.getElementById("current-year");
  const now = new Date();
  yearSpan.textContent = now.getFullYear();
}

// Attach event listeners after DOM content is loaded
document.addEventListener("DOMContentLoaded", () => {
  // Load products and customers, then render lists
  fetchProducts().then(() => {
    renderProducts();
  });
  loadCustomers();
  renderCustomerList();
  // Brand search events
  const brandSearchInput = document.getElementById('brand-search');
  const brandSearchBtn = document.getElementById('brand-search-btn');
  if (brandSearchInput && brandSearchBtn) {
    // Clicking the search button triggers a filter
    brandSearchBtn.addEventListener('click', (e) => {
      e.preventDefault();
      brandSearchTerm = brandSearchInput.value;
      renderProducts();
    });
    // Pressing Enter in the input also triggers a filter
    brandSearchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        brandSearchTerm = brandSearchInput.value;
        renderProducts();
      }
    });
    // Live update on input
    brandSearchInput.addEventListener('input', () => {
      brandSearchTerm = brandSearchInput.value;
      renderProducts();
    });
  }
  // Model search events
  const modelSearchInput = document.getElementById('model-search');
  const modelSearchBtn = document.getElementById('model-search-btn');
  if (modelSearchInput && modelSearchBtn) {
    // Clicking the search button triggers a filter
    modelSearchBtn.addEventListener('click', (e) => {
      e.preventDefault();
      modelSearchTerm = modelSearchInput.value;
      renderProducts();
    });
    // Pressing Enter in the input triggers a filter
    modelSearchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        modelSearchTerm = modelSearchInput.value;
        renderProducts();
      }
    });
    // Live update on input
    modelSearchInput.addEventListener('input', () => {
      modelSearchTerm = modelSearchInput.value;
      renderProducts();
    });
  }
  // Customer form submission
  document
    .getElementById('customer-form')
    .addEventListener('submit', handleCustomerSubmit);
  // Customer search events
  const customerSearchInput = document.getElementById('customer-search');
  if (customerSearchInput) {
    customerSearchInput.addEventListener('input', (e) => {
      renderCustomerList(e.target.value);
    });
  }
  updateYear();
});